<?php

namespace App\Exceptions;

use Exception;

class InvalidTransaction extends Exception
{
    //
}
